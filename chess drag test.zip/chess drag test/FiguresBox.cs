﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chess_drag_test
{
    static class FiguresBox
    {
        private static Figure[] figuresArray;
        private static Figure[] blackFiguresArray;
        private static Figure[] whiteFiguresArray;

        static FiguresBox()
        {
            figuresArray = new Figure[] {
                                new Figure(Types.rook, Colors.white),
                                new Figure(Types.knight, Colors.white),
                                new Figure(Types.bishop, Colors.white),
                                new Figure(Types.queen, Colors.white),
                                new Figure(Types.king, Colors.white),
                                new Figure(Types.bishop, Colors.white),
                                new Figure(Types.knight, Colors.white),
                                new Figure(Types.rook, Colors.white),

                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),
                                new Figure(Types.pawn, Colors.white),

                                new Figure(Types.rook, Colors.black),
                                new Figure(Types.knight, Colors.black),
                                new Figure(Types.bishop, Colors.black),
                                new Figure(Types.queen, Colors.black),
                                new Figure(Types.king, Colors.black),
                                new Figure(Types.bishop, Colors.black),
                                new Figure(Types.knight, Colors.black),
                                new Figure(Types.rook, Colors.black),

                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black),
                                new Figure(Types.pawn, Colors.black)
                        };

            whiteFiguresArray = new Figure[16];
            blackFiguresArray = new Figure[16];

            for (int i = 0; i < 16; i++)
            {
                whiteFiguresArray[i] = figuresArray[i];
                blackFiguresArray[i] = figuresArray[i + 16];
            }
        }

        public static Figure[] Figures
        {
            get { return figuresArray; }
        }

        public static Figure[] WhiteFigures
        {
            get { return whiteFiguresArray; }
        }

        public static Figure[] BlackFigures
        {
            get { return blackFiguresArray; }
        }
    }
}

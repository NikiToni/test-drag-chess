﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chess_drag_test
{
    static class ChessLogic
    {
        


/*
        public static Figure[] getFiguresOnTable()
        {
            Figure[] retFigArr;
            int numbOfFigOnTable = 0;
            
            foreach (Figure figure in FiguresBox.Figures)
            {
                if (figure.OnTable)
                {
                    numbOfFigOnTable++;
                }
            }

            retFigArr = new Figure[numbOfFigOnTable];

            int i = 0;

            foreach (Figure figure in FiguresBox.Figures)
            {
                if (figure.OnTable)
                {
                    retFigArr[i] = figure;
                    i++;
                }
            }

            return retFigArr;
        }
        */
    }
}
